import React from "react";
const Text = ({ data }) => {
  return <div>{data}</div>;
};
export default Text;
